import{Y as a}from"./vendor-11b87e0a.js";import{aa as m}from"./index-66142cee.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
